# -*- coding: utf-8 -*-
"""
Deprecated Library
==================

Python ``@deprecated`` decorator to deprecate old python classes, functions or methods.

"""

__version__ = "1.2.12"
__author__ = u"Laurent LAPORTE <tantale.solutions@gmail.com>"
__date__ = "2020-03-13"
__credits__ = "(c) Laurent LAPORTE"

from deprecated.classic import deprecated
