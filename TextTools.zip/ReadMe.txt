功能简介：
EPUBtoTXT：epub格式转换为txt。解决calibre转换中注音下移问题（所以我直接把注音删了）
EPUBtoDOCX：epub格式转换为docx（不删注音）
RBforTXT：为txt格式日语文本注假名（食用前记得选择保存方式（滚轮可以上下划））


食用方式：
打开Interface.exe启动程序


注意事项：
保存图片转换出错请在configuration中关掉（True-->False）

拒绝访问 和 目录不是空的 报错只要再来一次就好
Permission denied 报错请检查是否打开文件

RBforTXT使用hiragana.jp注音需要Chrome浏览器
注音速度可能有点慢
所有文件（除了这个txt）需要在同级目录
程序读取backg.jpg（282x400 etc.）作为背景（不会有人在这种功能上花时间吧）
有一些进程可能无法关闭，请用任务管理器关闭

如果chromedriver.exe有问题请到（此版本对应Chrome版本91）
http://chromedriver.storage.googleapis.com/index.html
下载对应Chrome版本的chromedriver.exe并替换


肯定存在大量bug……


Author:DrMelt

--2021.7.23--
.docx保存图像（可在configuration中关掉）

--2021.7.17--
优化
用Nuitka打包以降低运行速度

---2021.7.11 v1.2---
增加RBforTXT保存为.docx格式功能
增加RBforTXT使用pykakasi注音功能
增加设置功能（configuration为配置文件）


---2021.6.21 v1.1---
修复了根本无法使用的bug



